/*
 * @Author: veni
 * @Date: 2019-11-07 17:16:33
 * @LastEditors: veni
 * @LastEditTime: 2019-11-12 16:08:17
 * @Description: 项目入口文件。
 */
const Koa = require('koa')
const path = require('path')
const bodyParser = require('koa-bodyparser')
const nunjucks = require('koa-nunjucks-2')
// 引入 koa-static
const staticFiles = require('koa-static')

const app = new Koa()
const router = require('./router')
const middleware = require('./middleware')

middleware(app)

// // 指定 public目录为静态资源目录，用来存放 js css images 等
// app.use(staticFiles(path.resolve(__dirname, "./public")))

// app.use(nunjucks({
//   ext: 'html', // 指定视图文件默认后缀 
//   path: path.join(__dirname, 'views'), // 指定视图目录
//   nunjucksConfig: {
//     trimBlocks: true // 开启转义，防止 Xss 漏洞
//   }
// }));

// app.use(bodyParser())
router(app)
app.listen(8888, () => {
  console.log('server is running at http://localhost:8888')
})